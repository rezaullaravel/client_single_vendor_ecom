-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 22, 2024 at 02:49 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `client-ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int NOT NULL,
  `image` text NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  `updated_at` timestamp(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `image`, `description`, `created_at`, `updated_at`) VALUES
(1, 'upload/about_us_image/80096110.about.jpg', 'orem ipsum, dolor sit amet consectetur adipisicing elit. Amet, rerum quod. Placeat iure neque ab recusandae ipsam. Odio vitae commodi hic? Autem quasi rem non dignissimos aut possimus quo dolorum, omnis earum tempore ipsum tempora temporibus debitis voluptatum dolor quis distinctio molestiae mollitia quos at reiciendis delectus? Saepe nesciunt beatae, cupiditate earum, dolor quas reprehenderit officiis ea explicabo vel fuga perspiciatis hic eum alias ipsam illum. Tempora nesciunt dicta non? Vitae alias nobis quod facere, officiis cupiditate animi similique? Doloribus perspiciatis delectus et eaque distinctio alias ex pariatur facere magnam ab harum officiis at illo tenetur numquam rem necessitatibus odit obcaecati, error aspernatur iure ipsa voluptates neque. Repellendus obcaecati esse soluta ad ab id doloremque excepturi, quod quaerat quidem fugiat, optio reiciendis tenetur voluptatibus at inventore! Doloremque iure, numquam, consequuntur vel eveniet quo nesciunt libero quaerat non, ducimus dolorem laudantium tempore ipsum nihil? Repudiandae officia expedita animi eos incidunt ipsum necessitatibus, adipisci esse dolores? Mollitia minima quod perspiciatis eaque nisi harum, inventore quasi hic pariatur aspernatur exercitationem ipsam provident, optio recusandae eos? Deserunt aspernatur totam esse debitis sunt reiciendis quae perferendis et labore ad voluptatibus consequuntur vero rerum delectus asperiores, ipsa ea facere, iure nihil sit eaque? Magnam alias atque veniam, consequatur, nemo unde reprehenderit officiis minus id placeat et reiciendis! Itaque cumque iusto unde eos, odit nemo, error consectetur amet voluptates hic obcaecati non eveniet deserunt, quia incidunt at adipisci totam officia. Rerum molestias repellendus sunt ea, tempora quisquam. Alias illum consequuntur unde corrupti odio suscipit, accusamus porro exercitationem obcaecati incidunt ullam eius, repudiandae ex maiores architecto ratione voluptas fugiat. Ad ex rerum earum nihil! Illo exercitationem dolorum ex architecto ratione? Voluptas eius iste debitis officiis animi earum, modi necessitatibus! Ipsam magni ut unde reiciendis fuga repudiandae commodi, dignissimos quia! Velit rem tempore expedita ipsum iste consequuntur accusantium officiis uuuu', '0000-00-00 00:00:00.000000', '2024-09-11 08:32:22.000000');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Rezaul Karim', 'admin@gmail.com', NULL, '$2y$10$0bomueSYggyP5aN2R5lIwe3DAkvDPGQkbnmugPnw.4GCRd0GE4szK', '+880 1306 688607', 'upload/admin_images/917526068.sarukh (2).jpg', NULL, NULL, '2024-09-22 01:03:41');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint UNSIGNED NOT NULL,
  `brand_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_logo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_logo`, `created_at`, `updated_at`) VALUES
(9, 'Kiam', NULL, NULL, '2023-08-08 01:50:56'),
(8, 'Sony', 'upload/brand_images/475579801.laravel1.jpg', NULL, '2023-08-08 01:51:40'),
(7, 'Apple', 'upload/brand_images/91164016.blog3.jpg', NULL, '2023-08-08 01:51:51'),
(6, 'Toshiba', 'upload/brand_images/1865705820.blog2.jpg', NULL, '2023-08-08 01:52:03'),
(10, 'Buzzaz', NULL, NULL, NULL),
(11, 'Suzuki', NULL, NULL, NULL),
(12, 'Yamaha', NULL, NULL, NULL),
(13, 'Apache', NULL, NULL, NULL),
(14, 'Shorif', NULL, NULL, NULL),
(15, 'Tanin', NULL, NULL, NULL),
(16, 'RFL', NULL, NULL, NULL),
(17, 'Unileaver', NULL, NULL, NULL),
(18, 'Brothers', NULL, NULL, NULL),
(19, 'Sajid', NULL, NULL, NULL),
(20, 'Samsung', NULL, NULL, NULL),
(21, 'Vivo', NULL, NULL, NULL),
(22, 'BMW', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `category_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `created_at`, `updated_at`) VALUES
(10, 'Plastics', NULL, '2023-07-25 22:04:19', '2023-08-08 01:05:49'),
(2, 'Electronics', NULL, '2023-07-24 04:19:19', '2023-08-08 01:05:02'),
(3, 'Cosmetics', NULL, '2023-07-24 04:19:25', '2023-08-08 01:05:16'),
(4, 'Mechanics', NULL, '2023-07-24 04:19:37', '2023-08-08 01:05:28'),
(5, 'Fruit', NULL, '2023-07-24 04:19:42', '2023-08-08 01:06:01'),
(12, 'Electric', NULL, '2023-08-09 11:36:30', '2023-08-09 11:36:30');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Red', '#FF0000', NULL, NULL),
(2, 'Green', '#008000', NULL, NULL),
(3, 'Blue', '#0000FF', NULL, NULL),
(4, 'Black', '#000000', NULL, NULL),
(5, 'Orange', '#FFA500', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `color_products`
--

CREATE TABLE `color_products` (
  `id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `color_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `color_products`
--

INSERT INTO `color_products` (`id`, `product_id`, `color_id`, `created_at`, `updated_at`) VALUES
(58, 5, 3, '2024-09-19 02:58:41', '2024-09-19 02:58:41'),
(59, 5, 4, '2024-09-19 02:58:41', '2024-09-19 02:58:41'),
(60, 6, 4, '2024-09-19 02:59:08', '2024-09-19 02:59:08'),
(61, 6, 5, '2024-09-19 02:59:08', '2024-09-19 02:59:08'),
(64, 8, 3, '2024-09-19 03:00:04', '2024-09-19 03:00:04'),
(65, 8, 4, '2024-09-19 03:00:04', '2024-09-19 03:00:04'),
(66, 9, 1, '2024-09-19 03:00:40', '2024-09-19 03:00:40'),
(67, 9, 2, '2024-09-19 03:00:40', '2024-09-19 03:00:40'),
(68, 9, 3, '2024-09-19 03:00:40', '2024-09-19 03:00:40'),
(69, 10, 4, '2024-09-19 03:01:08', '2024-09-19 03:01:08'),
(70, 11, 4, '2024-09-19 03:01:25', '2024-09-19 03:01:25'),
(71, 12, 4, '2024-09-19 03:01:52', '2024-09-19 03:01:52'),
(72, 13, 3, '2024-09-19 03:02:05', '2024-09-19 03:02:05'),
(73, 7, 1, '2024-09-20 10:59:58', '2024-09-20 10:59:58'),
(74, 7, 4, '2024-09-20 10:59:58', '2024-09-20 10:59:58'),
(78, 4, 1, '2024-09-20 11:22:11', '2024-09-20 11:22:11'),
(79, 14, 1, '2024-09-22 08:47:56', '2024-09-22 08:47:56'),
(80, 14, 2, '2024-09-22 08:47:56', '2024-09-22 08:47:56'),
(81, 14, 5, '2024-09-22 08:47:56', '2024-09-22 08:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint UNSIGNED NOT NULL,
  `coupon_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `amount` int NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon_code`, `valid_date`, `type`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(1, 'mycoupon23', '2024-12-12', 1, 1000, '1', NULL, '2024-09-10 00:22:52');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_charges`
--

CREATE TABLE `delivery_charges` (
  `id` int NOT NULL,
  `amount` int NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  `updated_at` timestamp(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery_charges`
--

INSERT INTO `delivery_charges` (`id`, `amount`, `created_at`, `updated_at`) VALUES
(1, 300, '0000-00-00 00:00:00.000000', '2024-09-11 08:52:21.000000');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  `updated_at` timestamp(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(1, 'What is Lorem Ipsum?', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five http://jquery2dotnet.com/ centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2024-09-22 08:00:52.000000', '2024-09-22 08:00:52.000000'),
(2, 'Why do we use it?', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '2024-09-22 08:01:22.000000', '2024-09-22 08:01:22.000000'),
(3, 'Where does it come from?', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.', '2024-09-22 08:01:50.000000', '2024-09-22 08:01:50.000000'),
(4, 'Where can I get some?', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.', '2024-09-22 08:02:19.000000', '2024-09-22 08:02:19.000000'),
(6, 'What is laravel?', 'Laravel is a free, open-source PHP web framework designed for building web applications following the Model-View-Controller (MVC) architectural pattern. It aims to make common web development tasks like routing, authentication, sessions, and caching easier by providing a clean and expressive syntax.', '2024-09-22 08:16:27.000000', '2024-09-22 08:16:27.000000');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_06_20_135248_create_admins_table', 1),
(6, '2023_07_09_044236_create_categories_table', 1),
(8, '2023_07_26_024413_create_childcategories_table', 3),
(9, '2023_07_30_104400_create_brands_table', 4),
(10, '2023_07_31_145720_create_warehouses_table', 5),
(11, '2023_07_31_155825_create_coupons_table', 6),
(12, '2023_07_31_185426_create_products_table', 7),
(13, '2023_07_31_191746_create_pickuppoints_table', 8),
(14, '2023_08_01_220413_create_product_multi_images_table', 9),
(15, '2023_08_12_133824_create_reviews_table', 10),
(16, '2023_08_13_153748_create_wishlists_table', 11),
(18, '2023_08_15_110541_create_shopping_carts_table', 12),
(19, '2023_08_20_174216_create_orders_table', 13),
(20, '2023_08_20_174229_create_orderdetails_table', 13),
(21, '2024_03_25_171637_create_sliders_table', 14),
(22, '2024_03_30_122935_create_contacts_table', 15),
(24, '2024_09_07_102622_create_colors_table', 16);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id` bigint UNSIGNED NOT NULL,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `product_quantity` int NOT NULL,
  `price` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `order_id`, `product_id`, `product_quantity`, `price`, `color_id`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 1, '127500', 4, NULL, NULL),
(2, 1, 8, 1, '144000', 4, NULL, NULL),
(3, 2, 7, 1, '50000', 4, NULL, NULL),
(4, 3, 5, 1, '160000', 3, NULL, NULL),
(5, 4, 8, 2, '144000', 3, NULL, NULL),
(6, 5, 9, 2, '133000', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `c_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_shipping_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `c_zipcode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_discount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_charge` int NOT NULL,
  `subtotal` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `month` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id_no` int NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `c_name`, `c_phone`, `c_country`, `c_shipping_address`, `c_zipcode`, `c_city`, `coupon_code`, `coupon_discount`, `shipping_charge`, `subtotal`, `total`, `payment_type`, `date`, `day`, `month`, `year`, `order_id_no`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'user', '01719475187', 'Bangladesh', 'Singra, Natore.', NULL, NULL, 'mycoupon23', '1000', 300, '271500', '270800', 'hand_cash', '2024-09-10', '10', '09', '2024', 79278, '1', NULL, '2024-09-21 08:50:58'),
(2, 1, 'user', '01719475187', 'Bangladesh', 'Sherkole.', NULL, NULL, NULL, NULL, 300, '50000', '50300', 'hand_cash', '2024-09-10', '10', '09', '2024', 80528, '1', NULL, '2024-09-21 08:50:51'),
(3, 2, 'user2', '01322425179', 'Bangladesh', 'Teligram, Natore.', 'zct56', 'Natore.', NULL, NULL, 300, '160000', '160300', 'hand_cash', '2024-09-10', '10', '09', '2024', 10813, '0', NULL, '2024-09-10 07:13:29'),
(4, 1, 'user', '01719475187', 'Bangladesh', 'dfgdfhhfh', NULL, NULL, NULL, NULL, 300, '288000', '288300', 'hand_cash', '2024-09-13', '13', '09', '2024', 47667, '0', NULL, NULL),
(5, 1, 'user', '01719475187', 'Bangladesh', 'Natore rajshahi', 'cvcvcv', 'Natore', NULL, NULL, 300, '266000', '266300', 'hand_cash', '2024-09-18', '18', '09', '2024', 22357, '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint UNSIGNED NOT NULL,
  `category_id` int NOT NULL,
  `subcategory_id` int NOT NULL,
  `brand_id` int DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `purchase_price` int DEFAULT NULL,
  `selling_price` int DEFAULT NULL,
  `discount_price` int DEFAULT NULL,
  `stock_availability` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured` int DEFAULT NULL,
  `today_deal` int DEFAULT NULL,
  `best_selling` int NOT NULL,
  `product_view` int NOT NULL DEFAULT '0',
  `status` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `subcategory_id`, `brand_id`, `name`, `code`, `video`, `purchase_price`, `selling_price`, `discount_price`, `stock_availability`, `description`, `thumbnail`, `featured`, `today_deal`, `best_selling`, `product_view`, `status`, `created_at`, `updated_at`) VALUES
(4, 4, 7, 22, 'Luxury Private Car', 'lpc123', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/nwcNySYxZ6s?si=ZDw_m1DEjT8uADuK\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 1200000, 1080000, 10, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/1782006948.mechanic-car3.jpeg', 1, 1, 1, 20, 1, '2024-09-08 01:57:24', '2024-09-22 08:30:11'),
(5, 4, 7, 11, 'Suzuki Gixer-200', 'gix200', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/pWDP9HdoGj4?si=J6vTDdMxTmpg8k11\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 200000, 160000, 20, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/453766352.bike1.jpeg', 1, 1, 1, 10, 1, '2024-09-08 02:53:27', '2024-09-20 12:20:18'),
(6, 4, 8, 10, 'Discover-100', 'disc100', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/pWDP9HdoGj4?si=J6vTDdMxTmpg8k11\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 150000, 127500, 15, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/494505682.bike4.jpeg', 1, 1, 1, 51, 1, '2024-09-08 02:55:03', '2024-09-20 07:02:29'),
(7, 2, 4, 6, 'My Laptop', 'mlt100', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/kfGFzNncbtk?si=w6oY9H3WAyPe_Awx\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 50000, 50000, NULL, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/240809478.computer3.jpeg', 0, 1, 0, 39, 1, '2024-09-08 02:56:44', '2024-09-20 12:09:21'),
(8, 4, 8, 12, 'Yamaha-125', 'ymh125', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/pWDP9HdoGj4?si=J6vTDdMxTmpg8k11\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 160000, 144000, 10, '1', '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 'upload/product_images/85639845.moto1.jpeg', 1, 1, 1, 218, 1, '2024-09-08 06:03:54', '2024-09-21 04:48:33'),
(9, 4, 8, 12, 'Yamaha-100', 'ymh100', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/pWDP9HdoGj4?si=J6vTDdMxTmpg8k11\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 140000, 133000, 5, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/1178985328.bike1.jpeg', 1, 1, 1, 263, 1, '2024-09-08 06:06:21', '2024-09-22 02:01:15'),
(10, 10, 1, 14, 'Nice Table', 'nctable23', NULL, 5000, 4500, 10, '1', '<p>t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/1837632423.plastic-table.jpeg', 0, 0, 0, 51, 1, '2024-09-17 07:37:49', '2024-09-20 07:03:08'),
(11, 10, 1, 14, 'My chair', 'ch100', NULL, 2000, 2000, NULL, '1', '<p>t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/217608411.plastic-chair5.jpeg', 1, 1, 1, 68, 1, '2024-09-17 07:39:47', '2024-09-21 04:42:28'),
(12, 2, 3, 20, 'Samsung galaxy m002', 'gxm002', NULL, 12000, 11400, 5, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/719332581.mobile1.jpeg', 0, 1, 1, 2, 1, '2024-09-17 09:30:30', '2024-09-20 12:07:34'),
(13, 2, 3, 21, 'Vivo pro', 'vvopro900', NULL, 11000, 11000, NULL, '1', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'upload/product_images/1216702094.mobile3.jpeg', 0, 1, 0, 1, 1, '2024-09-17 09:33:24', '2024-09-19 08:11:57'),
(14, 10, 2, 16, 'Gorgious  sleeping', 'gsp34', NULL, 12000, 11400, 5, '1', '<p>nmbmbmnbmnbmnm</p>', 'upload/product_images/555502381.khat.jpeg', 1, 1, 1, 2, 1, '2024-09-20 11:09:41', '2024-09-22 08:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `product_multi_images`
--

CREATE TABLE `product_multi_images` (
  `id` bigint UNSIGNED NOT NULL,
  `product_id` int NOT NULL,
  `product_image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_multi_images`
--

INSERT INTO `product_multi_images` (`id`, `product_id`, `product_image`, `created_at`, `updated_at`) VALUES
(12, 5, 'upload/product_images/807539554.bike2.jpeg', '2024-09-08 02:53:27', '2024-09-08 02:53:27'),
(36, 4, 'upload/product_images/1622167290.mechanic-car.jpeg', '2024-09-20 11:22:11', '2024-09-20 11:22:11'),
(37, 4, 'upload/product_images/970716880.mechanic-car5.jpeg', '2024-09-20 11:22:11', '2024-09-20 11:22:11'),
(13, 5, 'upload/product_images/1753641931.bike3.jpeg', '2024-09-08 02:53:27', '2024-09-08 02:53:27'),
(14, 5, 'upload/product_images/1695660054.bike5.jpeg', '2024-09-08 02:53:27', '2024-09-08 02:53:27'),
(15, 6, 'upload/product_images/330969267.bike5 - Copy.jpeg', '2024-09-08 02:55:03', '2024-09-08 02:55:03'),
(16, 6, 'upload/product_images/652199653.bike5 - Copy.jpeg', '2024-09-08 02:55:03', '2024-09-08 02:55:03'),
(25, 10, 'upload/product_images/843867024.plastic-table.jpeg', '2024-09-17 07:37:49', '2024-09-17 07:37:49'),
(26, 10, 'upload/product_images/1766896896.plastic-table4.jpeg', '2024-09-17 07:37:49', '2024-09-17 07:37:49'),
(19, 8, 'upload/product_images/1783679374.bike3.jpeg', '2024-09-08 06:03:54', '2024-09-08 06:03:54'),
(20, 8, 'upload/product_images/691272858.bike4.jpeg', '2024-09-08 06:03:54', '2024-09-08 06:03:54'),
(21, 8, 'upload/product_images/1727193317.bike1.jpeg', '2024-09-08 06:03:55', '2024-09-08 06:03:55'),
(22, 9, 'upload/product_images/1702720497.bike2.jpeg', '2024-09-08 06:06:21', '2024-09-08 06:06:21'),
(23, 9, 'upload/product_images/233317023.bike3.jpeg', '2024-09-08 06:06:21', '2024-09-08 06:06:21'),
(24, 9, 'upload/product_images/1740249135.bike5.jpeg', '2024-09-08 06:06:21', '2024-09-08 06:06:21'),
(27, 11, 'upload/product_images/2110615126.plastic-chair5.jpeg', '2024-09-17 07:39:47', '2024-09-17 07:39:47'),
(28, 11, 'upload/product_images/1188530761.plastic-chari2.jpeg', '2024-09-17 07:39:47', '2024-09-17 07:39:47'),
(29, 11, 'upload/product_images/116453218.plastic-chari23jpeg.jpeg', '2024-09-17 07:39:47', '2024-09-17 07:39:47'),
(30, 12, 'upload/product_images/569786676.mobile2.jpeg', '2024-09-17 09:30:30', '2024-09-17 09:30:30'),
(31, 12, 'upload/product_images/785575124.mobile3.jpeg', '2024-09-17 09:30:30', '2024-09-17 09:30:30'),
(32, 12, 'upload/product_images/51317138.mobile5.jpeg', '2024-09-17 09:30:30', '2024-09-17 09:30:30'),
(33, 13, 'upload/product_images/323045859.mobile1.jpeg', '2024-09-17 09:33:24', '2024-09-17 09:33:24'),
(34, 13, 'upload/product_images/2103240571.mobile2.jpeg', '2024-09-17 09:33:24', '2024-09-17 09:33:24'),
(39, 14, 'upload/product_images/1381127271.khat.jpeg', '2024-09-22 08:47:56', '2024-09-22 08:47:56'),
(38, 4, 'upload/product_images/756420902.mechanic-car.jpeg', '2024-09-20 11:22:11', '2024-09-20 11:22:11'),
(40, 14, 'upload/product_images/1005377368.khat2.jpeg', '2024-09-22 08:47:56', '2024-09-22 08:47:56'),
(41, 14, 'upload/product_images/703398562.khat3.jpeg', '2024-09-22 08:47:56', '2024-09-22 08:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `review` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_point` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `review`, `rating_point`, `created_at`, `updated_at`) VALUES
(1, 1, 9, 'This is one of the best product in this market place. I have been using this product for seven years.', 5, '2024-09-11 09:18:16', NULL),
(2, 2, 9, 'Yes, This is an awesome motor cycle. I love this car very much.', 4, '2024-09-11 09:19:46', NULL),
(3, 2, 7, 'This laptop has very high configuration. core i5, 512gb ssd. 8gb ram. so nice. I like this laptop very much.', 5, '2024-09-11 09:48:32', NULL),
(4, 1, 8, 'This is an awesome product. I am very happy.', 4, '2024-09-20 09:26:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_carts`
--

CREATE TABLE `shopping_carts` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `color_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopping_carts`
--

INSERT INTO `shopping_carts` (`id`, `user_id`, `product_id`, `quantity`, `color_id`, `created_at`, `updated_at`) VALUES
(8, 1, 4, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `image`, `created_at`, `updated_at`) VALUES
(3, 'Slider one title.', 'upload/slider_images/1104337434.k-slider1.jpeg', '2024-03-25 12:45:41', '2024-03-25 13:25:00'),
(4, 'Slider title two.', 'upload/slider_images/1295277941.k-slider2.jpeg', '2024-03-25 12:45:55', '2024-03-25 13:25:08'),
(5, NULL, 'upload/slider_images/613655644.k-slider3.jpeg', '2024-03-25 12:46:00', '2024-03-25 13:25:15'),
(6, NULL, 'upload/slider_images/1015028650.ba1.jpg', '2024-03-25 12:46:10', '2024-03-25 13:25:26');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int NOT NULL,
  `category_id` int NOT NULL,
  `subcategory_name` varchar(255) NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  `updated_at` timestamp(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `subcategory_name`, `created_at`, `updated_at`) VALUES
(1, 10, 'Plastics-1', '2024-09-19 02:32:14.000000', '2024-09-19 02:32:14.000000'),
(2, 10, 'Plastics-2', '2024-09-19 02:32:28.000000', '2024-09-19 02:32:28.000000'),
(3, 2, 'Electronics-1', '2024-09-19 02:32:49.000000', '2024-09-19 02:32:49.000000'),
(4, 2, 'Electronics-2', '2024-09-19 02:33:13.000000', '2024-09-19 02:33:13.000000'),
(5, 3, 'Cosmetics-1', '2024-09-19 02:33:23.000000', '2024-09-19 02:33:23.000000'),
(6, 3, 'Cosmetics-2', '2024-09-19 02:33:34.000000', '2024-09-19 02:33:34.000000'),
(7, 4, 'Mechanics-1', '2024-09-19 02:33:45.000000', '2024-09-19 02:33:45.000000'),
(8, 4, 'Mechanics-2', '2024-09-19 02:33:54.000000', '2024-09-19 02:33:54.000000'),
(9, 5, 'Fruit-1', '2024-09-19 02:34:09.000000', '2024-09-19 02:34:09.000000'),
(11, 12, 'Electric-1', '2024-09-19 02:34:32.000000', '2024-09-19 02:34:32.000000'),
(12, 12, 'Electric-2', '2024-09-19 02:34:51.000000', '2024-09-19 02:34:51.000000'),
(13, 5, 'Fruit-2', '2024-09-19 02:38:32.000000', '2024-09-19 02:38:32.000000');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `image`, `address`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user@gmail.com', NULL, '$2y$10$t856NPuiHwUskDxyinbjfu1PNJXYL3LiwoXD11KXJ8r/CxaIaAPMe', '332211', 'upload/user_images/1538703256.sarukh (2).jpg', 'Singra, Natore.', '4fTuP4EG1Cel3QeapwkIPoMAPbU9LFAzKYKKGDvOyhsbrzlMB11wFGQKM0AB', '2023-07-24 04:11:53', '2024-09-21 10:05:50'),
(2, 'user2', 'user2@gmail.com', NULL, '$2y$10$rQZaTMi4LcwymwZPKBCAmOajKeIj1pA6In47npwWUpSo9Z2Cxk7Ua', '446677', 'upload/user_images/1633108752.g4.jpg', 'Sirajganj, Rajshai.', NULL, '2023-08-12 07:02:57', '2024-09-21 10:04:21'),
(3, 'karim', 'karim@gmail.com', NULL, '$2y$10$IZQH/t/lH4CKXcAHyMfLs.qhfccHaXlC7wG8ern8vHNjVfWkLBppG', '6666666', 'upload/user_images/171750793.rose4.jpg', NULL, NULL, '2023-08-17 23:46:26', '2024-09-21 10:03:40'),
(5, 'Jannat', 'jannat@gmail.com', NULL, '$2y$10$byGMyBPwUVHgXZfEQrxPKOXD2ztNWDLHAD8k3jwkKtn6vtoHywie.', '0122334455', 'upload/user_images/896170933.rose3 - Copy.jpg', 'Singra ,Natore', NULL, '2024-09-21 09:36:49', '2024-09-21 09:36:49'),
(7, 'belal', 'belal@gmail.com', NULL, '$2y$10$u7JppsMk6vLLWJzyonPTw.2hdu9xfxEA.F9NYT7YNCEItLGGtqsFC', '009988', 'upload/user_images/1454430347.g1.jpg', 'Jhinaidah, Bangladesh.', NULL, '2024-09-22 01:23:55', '2024-09-22 02:00:40'),
(6, 'Amena Khatun', 'amena@gmail.com', NULL, '$2y$10$aKNjtKjTL51qcjR6PVtWlObWWRLoEVRTiCCfA5zgpusGmEwlD5nIK', '14321', 'upload/user_images/1583715266.runa.png', 'Teligram, Sherkole,Natore.', NULL, '2024-09-21 10:09:12', '2024-09-21 10:09:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `colors_name_unique` (`name`);

--
-- Indexes for table `color_products`
--
ALTER TABLE `color_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_charges`
--
ALTER TABLE `delivery_charges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_multi_images`
--
ALTER TABLE `product_multi_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_carts`
--
ALTER TABLE `shopping_carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `color_products`
--
ALTER TABLE `color_products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery_charges`
--
ALTER TABLE `delivery_charges`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_multi_images`
--
ALTER TABLE `product_multi_images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shopping_carts`
--
ALTER TABLE `shopping_carts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
